//: generics/coffee/Mocha.java
package generics.coffee;
public class Mocha extends Coffee {} ///:~
